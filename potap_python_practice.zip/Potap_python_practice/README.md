# Form Template Finder

## Описание
Программа находит шаблон формы на основе переданных параметров и валидирует их по типам.

## Установка

```bash
pip install -r requirements.txt
```

## Запуск

```bash
python app.py get_tpl --customer=John Smith --дата_заказа=27.05.2025
```

## Тесты

```bash
pytest test_app.py
```
